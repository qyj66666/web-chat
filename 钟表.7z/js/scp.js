var ca1 = document.getElementById("ca1");
var ca2 = document.getElementById("ca2");
var ca3 = document.getElementById("ca3");
var ca4 = document.getElementById("ca4");
var cont1 = ca1.getContext("2d");
cont1.lineWidth = "0.5";
cont1.strokeStyle = "red";
var cecle = {
	X1: 0,
	Y1: 0,
	X2: 0,
	Y2: 0,
	X3: 0,
	Y3: 0,
	center: [0, 0],
	R: 0,
	setR(r = 0) {
		this.R = r;
	},
	getXY(t = 0) {
		var d = 0;
		var ht = 0;
		if (t % 90 == 0) {
			d = 15;
			ht = 30;
		} else if (t % 10 == 0) {
			d = 9;
			ht = 30;
		} else {
			d = 3;
		}
		this.X1 = this.center[0] + this.R * Math.cos(t * Math.PI / 180);
		this.Y1 = this.center[1] + this.R * Math.sin(t * Math.PI / 180);
		this.X2 = this.center[0] + (this.R - d) * Math.cos(t * Math.PI / 180);
		this.Y2 = this.center[1] + (this.R - d) * Math.sin(t * Math.PI / 180);
		this.X3 = this.center[0] + (this.R - ht) * Math.cos(t * Math.PI / 180);
		this.Y3 = this.center[1] + (this.R - ht) * Math.sin(t * Math.PI / 180);
		return ht;
	},
	setCenter(x = 0, y = 0) {
		this.center[0] = x;
		this.center[1] = y;
	}
};
var a = cecle;
a.setCenter(250, 250);
a.setR(250);
a.getXY(0);
for (var i = 0; i <= 360; i = i + 6) {
	var t = a.getXY(i);
	if (t == 30) {
		console.log(a.X3,a.Y3);
		var j = i.toString()/30+3;
		cont1.font = "15px 黑体";
		if(j == 13 || j == 14){
			cont1.fillText(j%12,a.X3,a.Y3);
		}else if(j<15){
			if(j>=9 && j <= 12 ){
				cont1.fillText(j, a.X3-8, a.Y3+4);
			}else if(j>=3 &&j<=8){
				cont1.fillText(j, a.X3-5, a.Y3+6);	
			}else{
				cont1.fillText(j, a.X3, a.Y3);	
			}
		}
		
	}
	cont1.moveTo(a.X1, a.Y1);
	cont1.lineTo(a.X2, a.Y2);
	cont1.stroke();
}
var cont2 = ca2.getContext("2d");
cont2.lineWidth = "1";
cont2.arc(200, 200, 30, 0, 360, false);
cont2.stroke();
cont2.moveTo(200, 170);
cont2.lineTo(200, 0);
cont2.lineTo(170, 30);
cont2.moveTo(200, 0);
cont2.lineTo(230, 30);
cont2.stroke();
var cont3 = ca3.getContext("2d");
cont3.lineWidth = "3";
cont3.strokeStyle = "red";
cont3.arc(200, 200, 50, 0, 360, false);
cont3.stroke();
cont3.moveTo(200, 150);
cont3.lineTo(200, 30);
cont3.lineTo(170, 60);
cont3.moveTo(200, 30);
cont3.lineTo(230, 60);
cont3.stroke();
var cont4 = ca4.getContext("2d");
cont4.lineWidth = "5";
cont4.strokeStyle = "blue";
cont4.arc(200, 200, 70, 0, 360, false);
cont4.stroke();
cont4.moveTo(200, 130);
cont4.lineTo(200, 60);
cont4.lineTo(170, 90);
cont4.moveTo(200, 60);
cont4.lineTo(230, 90);
cont4.stroke();
var timer1 = new Date();
var hours = timer1.getHours();
var minutes = timer1.getMinutes();
var seconds = timer1.getSeconds() + 1;
var i = seconds * 6;
var j = minutes * 6 + 6 * (seconds / 60);
var k = hours * 30 + 30 * (minutes / 60);
setInterval(function() {
	var str = "rotate(" + i + "deg)";
	var str1 = "rotate(" + j + "deg)";
	var str2 = "rotate(" + k + "deg)";
	ca2.style.transform = str;
	ca3.style.transform = str1;
	ca4.style.transform = str2;
	i = i + 6;
	j = j + 6 * (1 / 60);
	if (i == 360) {
		i = 0;
		k = k + 30 * (1 / 60);
		if (j == 360) {
			j = 0;
			if (k == 24 * 30) {
				k = 0;
			}
		}
	}
}, 1000);
